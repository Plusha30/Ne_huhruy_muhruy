from flask import Flask, render_template, request, redirect, url_for
import os
import json
import pathlib
import shutil

app = Flask(__name__)
tovars_data = {}
users_base = {}
email = 'placeholder'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

def return_image(path, placeholder):
    if os.path.exists(f"{pathlib.Path(__file__).parent.resolve()}/static/images/{path}.jpg"):
        return f'images/{path}.jpg'
    else:
        return f'images/common/{placeholder}.jpg'

def commonkwargs(kwargs):
    if (email in users_base):
        return kwargs | {'username': users_base[email][1], 'userimg': return_image(f'users/{email}', 'user_placeholder')}
    else:
        return kwargs | {'username': 'Вы', 'userimg': return_image(f'users/{email}', 'user_placeholder')}

@app.route('/category/compare/<name>')
def compare(name):
    kwargs = {"tovars": tovars_data[name]['tovars'], "categoryid": name, 'categoryname': tovars_data[name]['name']}
    return render_template('compare.html', **commonkwargs(kwargs))

@app.route('/category/<name>', methods=['GET', 'POST'])
def category(name):
    kwargs = {"tovarlist": tovars_data[name]["tovars"], "category": name, "categoryname": tovars_data[name]['name']}
    if (request.method == 'GET'):
        kwargs['data'] = {}
        return render_template('category.html', **commonkwargs(kwargs))
    else:
        data = request.form.to_dict(flat=False)
        kwargs["data"] = data
        return render_template('category.html', **commonkwargs(kwargs))

@app.route('/category/<categoryname>/tovar/<name>')
def tovar(categoryname, name):
    return render_template('tovar.html', **commonkwargs({"categoryname": tovars_data[categoryname]['name'], "category": categoryname, \
                                                         "tovarid": name, "tovar": tovars_data[categoryname]['tovars'][name]}))

@app.route('/')
def root():
    return render_template('main.html', **commonkwargs({'tovarlist': tovars_data}))

@app.route("/register", methods=['GET', 'POST'])
def register():
    return render_template('register.html', **commonkwargs({}))
 
@app.route("/edit_profile", methods=['GET', 'POST'])
def edit_profile():
    global email
    if (email == 'placeholder'):
        return redirect(url_for('enter'), 301)
    if (request.method == 'GET'):
        kwargs = {'useremail': email, 'userphone': users_base[email][2], 'userpassword': users_base[email][0]}
        return render_template('edit_profile.html', **commonkwargs(kwargs))
    else:
        data = request.form.to_dict(flat=False)
        phone = ''
        if (len(data['phone']) == 0 or data['phone'][0] == ''):
            phone = 'Не указан'
        else:
            phone = data['phone'][0]
        users_base[email] = [data['password'][0], data['name'][0], phone]
        with open(f"{pathlib.Path(__file__).parent.resolve()}/users_base.txt", 'w', encoding='utf-8') as f:
            f.write(json.dumps(users_base, indent=4))
        photo = request.files['file']
        if (photo.filename != ''):
            path = f"{pathlib.Path(__file__).parent.resolve()}/static/images/users/{email}.jpg"
            photo.save(path)
        return redirect(url_for('cabinet'), 301)

@app.route("/enter", methods=['GET', 'POST'])
def enter():
    global email
    if (email != 'placeholder'):
        return redirect(url_for('cabinet'), 301) 
    wrong = request.args.get('wrong')
    if (request.method == 'POST'):
        data = request.form.to_dict(flat=False)
        phone = ''
        if (len(data['phone']) == 0 or data['phone'][0] == ''):
            phone = 'Не указан'
        else:
            phone = data['phone'][0]
        users_base[data['email'][0]] = [data['password'][0], data['name'][0], phone]
        email = data['email'][0]
        with open(f"{pathlib.Path(__file__).parent.resolve()}/users_base.txt", 'w', encoding='utf-8') as f:
            f.write(json.dumps(users_base, indent=4))
        photo = request.files['file']
        if (photo.filename != ''):
            path = f"{pathlib.Path(__file__).parent.resolve()}/static/images/users/{email}.jpg"
            photo.save(path)
    return render_template('enter.html', **commonkwargs({'wrong': wrong}))

@app.route("/cabinet", methods=['GET', 'POST'])
def cabinet():
    global email
    if (request.method == 'GET' and email == 'placeholder'):
        return redirect(url_for('enter'), 301)
    global tovars_data
    imagepath = f''
    if (request.method == 'POST'):
        data = request.form.to_dict(flat=False)
        if ('newtovar' in data):
            for i in tovars_data:
                if (tovars_data[i]['name'] == data['cat'][0]):
                    with open(f"{pathlib.Path(__file__).parent.resolve()}/tovars/{tovars_data[i]['id']}/{len(tovars_data[i]['tovars']) + 1}.txt", 'w', encoding='utf-8') as f:
                        temp = {f'{len(tovars_data[i]["tovars"]) + 1}': {}}
                        for j in data:
                            if (j != 'newtovar' and j != 'newtovar'):
                                temp[f'{len(tovars_data[i]["tovars"]) + 1}'][j] = data[j][0] 
                        temp[f'{len(tovars_data[i]["tovars"]) + 1}']['rating'] = max(0, min(5, int(temp[f'{len(tovars_data[i]["tovars"]) + 1}']['rating'])))               
                        temp[f'{len(tovars_data[i]["tovars"]) + 1}'] |= {'commentaries': []}
                        photo = request.files['file']
                        if (photo.filename != ''):
                            path = f"{pathlib.Path(__file__).parent.resolve()}/static/images/categories/{i}/{len(tovars_data[i]['tovars']) + 1}.jpg"
                            photo.save(path)
                        else:
                            shutil.copy2(f"{pathlib.Path(__file__).parent.resolve()}/static/images/common/placeholder.jpg", f"{pathlib.Path(__file__).parent.resolve()}/static/images/categories/{i}/{len(tovars_data[i]['tovars']) + 1}.jpg")
                        f.write(json.dumps(temp, indent=4))
                        tovars_data[i]['tovars'] |= temp
        else:
            if (data['email'][0] in users_base and users_base[data['email'][0]][0] == data['password'][0]):
                    email = data['email'][0]
                    imagepath = return_image(f'users/{email}', 'user_placeholder')
                    kwargs = {'useremail': email, 'username': users_base[email][1], 'userphone': users_base[email][2], 'userimg': imagepath}
                    return render_template('cabinet.html', **commonkwargs(kwargs))
            else:
                return redirect(url_for('enter', wrong = 1), 301)
    imagepath = return_image(f'users/{email}', 'user_placeholder')
    kwargs = {'useremail': email, 'username': users_base[email][1], 'userphone': users_base[email][2], 'userimg': imagepath}
    return render_template('cabinet.html', **commonkwargs(kwargs))

@app.route("/exit")
def exitpage():
    global email
    email = 'placeholder'
    return redirect(url_for('enter'))

@app.route("/new_tovar")
def new_tovar():
    if (email == 'placeholder'):
        return redirect(url_for('enter'), 301)
    return render_template('new_tovar.html', **commonkwargs({'tovars_data': tovars_data}))

def getTovarsData(folder_path):
    total = dict()
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            d = json.loads(content)
            total |= d
            for i in d:
                d[i] |= {"tovars": {}}
            way = f"{pathlib.Path(__file__).parent.resolve()}/tovars/{filename[:-4]}"
            for tovar in os.listdir(way):
                tovar_path = os.path.join(way, tovar)
                with open(tovar_path, 'r', encoding='utf-8') as f1:
                    info = f1.read()
                    tov = json.loads(info)
                    for i in d:
                        d[i]["tovars"] |= tov
    return total

if __name__ == '__main__':
    tovars_data = getTovarsData(f"{pathlib.Path(__file__).parent.resolve()}/categories")
    with open(f"{pathlib.Path(__file__).parent.resolve()}/users_base.txt", 'r', encoding='utf-8') as f:
        info = f.read()
        users_base = json.loads(info)
    app.run(port=5136, host="0.0.0.0", debug=True)
