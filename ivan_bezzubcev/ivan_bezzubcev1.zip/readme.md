Made by Bezzubcev Ivan, 10 infoprofile student.

Instructions to installation:
    - Download Python 3.11+ and pip package manager
    - Download required libraries through pip (if not preinstalled)
    - Run "host.py"
    - Open [http:](http://127.0.0.1:5136/) in your browser